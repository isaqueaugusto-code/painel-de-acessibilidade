let tamanhoFonte = 16;

function mostrarMensagem(texto) {

    const mensagem = document.getElementById("mensagem");

    mensagem.textContent = texto;

}

function aumentarTexto() {

    if (tamanhoFonte < 26) {

        tamanhoFonte += 2;

        document.body.style.fontSize = tamanhoFonte + "px";

        mostrarMensagem("Texto aumentado.");

    } else {

        mostrarMensagem("O tamanho máximo do texto foi atingido.");

    }

}


function diminuirTexto() {

    if (tamanhoFonte > 12) {

        tamanhoFonte -= 2;

        document.body.style.fontSize = tamanhoFonte + "px";

        mostrarMensagem("Texto diminuído.");

    } else {

        mostrarMensagem("O tamanho mínimo do texto foi atingido.");

    }

}


function altoContraste() {

    document.body.classList.toggle("alto-contraste");

    if (document.body.classList.contains("alto-contraste")) {

        mostrarMensagem("Alto contraste ativado.");

    } else {

        mostrarMensagem("Alto contraste desativado.");

    }

}



function lerPagina() {

    speechSynthesis.cancel();

    const conteudo = document.getElementById("conteudo");

    const texto = conteudo.innerText;

    const leitura = new SpeechSynthesisUtterance(texto);

    leitura.lang = "pt-BR";

    leitura.rate = 1;

    speechSynthesis.speak(leitura);

    mostrarMensagem("Leitura iniciada.");

}



function pararLeitura() {

    speechSynthesis.cancel();

    mostrarMensagem("Leitura interrompida.");

}

function destacarElementos() {

    document.body.classList.toggle("destacar");

    if (document.body.classList.contains("destacar")) {

        mostrarMensagem("Links e botões destacados.");

    } else {

        mostrarMensagem("Destaque removido.");

    }

}


function modoMonocromatico() {

    document.body.classList.toggle("monocromatico");

    if (document.body.classList.contains("monocromatico")) {

        mostrarMensagem("Modo monocromático ativado.");

    } else {

        mostrarMensagem("Modo monocromático desativado.");

    }

}



function simplificarConteudo() {

    document.body.classList.toggle("simplificado");

    if (document.body.classList.contains("simplificado")) {

        mostrarMensagem("Conteúdo simplificado.");

    } else {

        mostrarMensagem("Conteúdo completo restaurado.");

    }

}


function expandirTela() {

    document.body.classList.toggle("tela-expandida");

    if (document.body.classList.contains("tela-expandida")) {

        mostrarMensagem("Tela expandida.");

    } else {

        mostrarMensagem("Tela reduzida.");

    }

}